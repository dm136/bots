const help = (prefix) => { 
	return `   *🍁MENU HANGDEHBOT🍁*
	
	
*╭═┅ৡৢ͜͡✦═══╡꧁꧂╞═══┅ৡৢ͜͡✦═╮*
*║┊:* ⃟ ⃟  ━ೋ๑————๑ೋ━* ⃟ ⃟ *      
*║┊:◄✜┢┅ீ͜ৡৢ͜͡✦━━◇━━ீ͜ৡৢ͜͡✦┅┧✜►*
*║┊:*      ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈  
*║┊:* _Botname : Hangdeh BOT_
*║┊:* _Owner : Sandy Jr_
*║┊:* _WARNING!! : DILARANG COPY!_
*║┊:*      ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ 
*║┊:◄✜┢┅ீ͜ৡৢ͜͡✦━━◇━━ீ͜ৡৢ͜͡✦┅┧✜►*
*║┊:  * ⃟ ⃟  ━ೋ๑————๑ೋ━* ⃟ ⃟ *   
*╰═┅ৡৢ͜͡✦═══╡꧁꧂╞═══┅ৡৢ͜͡✦═╯*

╭▬▬▬▬▬▬▬▬ *˚✯ཻ⸙۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪ࣤ ̥•┉┉•
⊱✦•* _Fitur BOT_
▋╭┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅   
▋┋*${prefix}ingfo
▋┋*${prefix}owner
▋┋*${prefix}donasi
▋┋*${prefix}repot
▋┋*${prefix}speed
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙_Media_
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}sticker
▋┋*${prefix}toimg
▋┋*${prefix}wait
▋┋*${prefix}kbbi
▋┋*${prefix}imoji
▋┋*${prefix}anjing
▋┋*${prefix}randomcat
▋┋*${prefix}ssweb
▋┋*${prefix}memeindo
▋┋*${prefix}meme
▋┋*${prefix}tep
▋┋*${prefix}tts
▋┋*${prefix}pinterest
▋┋*${prefix}fototiktok
▋┋*${prefix}tiktokstalk
▋┋*${prefix}ytmp4
▋┋*${prefix}ocr
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙_Maker_
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}firetext
▋┋*${prefix}snowrite
▋┋*${prefix}marvelogo
▋┋*${prefix}text3d
▋┋*${prefix}lionlogo
▋┋*${prefix}water
▋┋*${prefix}ninjalogo
▋┋*${prefix}textblue
▋┋*${prefix}textdark
▋┋*${prefix}quotemarker
▋┋*${prefix}wolflogo
▋┋*${prefix}phlogo
▋┋*${prefix}glitch
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙_Anime_
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}openanime
▋┋*${prefix}anime
▋┋*${prefix}neko
▋┋*${prefix}loli
▋┋*${prefix}waifu
▋┋*${prefix}waifu2
▋┋*${prefix}randomanime
▋┋*${prefix}pokemon
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙_Fun_
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}artinama
▋┋*${prefix}truth
▋┋*${prefix}dare
▋┋*${prefix}game
▋┋*${prefix}bucin
▋┋*${prefix}persengay
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙_Ingfokan_
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}ingfogc
▋┋*${prefix}ingfogempa
▋┋*${prefix}ingfocuaca
▋┋*${prefix}ingfonomor
▋┋*${prefix}groupingfo
▋┋*${prefix}lirik
▋┋*${prefix}quotes
▋┋*${prefix}cerpen
▋┋*${prefix}chord
▋┋*${prefix}wiki
▋┋*${prefix}resep
▋┋*${prefix}map
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙_Fitur Grup_
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}add
▋┋*${prefix}kick
▋┋*${prefix}promote
▋┋*${prefix}demote
▋┋*${prefix}setnamegc
▋┋*${prefix}setdescgc
▋┋*${prefix}welcome
▋┋*${prefix}nsfw
▋┋*${prefix}simih
▋┋*${prefix}group
▋┋*${prefix}tagme
▋┋*${prefix}hidetag
▋┋*${prefix}tagall
▋┋*${prefix}fitnah
▋┋*${prefix}ingfogc
▋┋*${prefix}groupingfo
▋┋*${prefix}linkgc
▋┋*${prefix}listadmins
▋┋*${prefix}openanime
▋┋*${prefix}edotense
▋┋*${prefix}kudeta
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙_NSFW Menu_
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}nsfwloli
▋┋*${prefix}nswfblowjob
▋┋*${prefix}nsfwneko
▋┋*${prefix}nsfwtrap
▋┋*${prefix}randomhentai
▋┋*${prefix}indohot
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙_Kerang_
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}apakah
▋┋*${prefix}kapankah
▋┋*${prefix}bisakah
▋┋*${prefix}rate
▋┋*${prefix}watak
▋┋*${prefix}hobi
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙_Others_
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}blocklist
▋┋*${prefix}say
▋┋*${prefix}hilih
▋┋*${prefix}testime
▋┋*${prefix}delete
▋┋*${prefix}shorturl
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙_Premium fitur_ (gada duit gw cok)
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}galaxtext 
▋┋*${prefix}primbonjodoh
▋┋*${prefix}ramaljadian
▋┋*${prefix}tahta
▋┋*${prefix}lovemaker
▋┋*${prefix}thunder
▋┋*${prefix}stiltext
▋┋*${prefix}ttp
▋┋*${prefix}wallpaperhd
▋┋*${prefix}tsticker
▋┋*${prefix}url2img
▋┋*${prefix}playstore
▋┋*${prefix}unta
▋┋*${prefix}inu
▋┋*${prefix}elang
▋┋*${prefix}ytmp3
▋┋*${prefix}joox
▋┋*${prefix}image
▋┋*${prefix}tebakgambar
▋┋*${prefix}caklontong
▋┋*${prefix}family100
▋┋*${prefix}igstalk
▋┋*${prefix}tiktok
▋┋*${prefix}ytsearch
▋┋*${prefix}nulis
▋┋*${prefix}textscreen
▋┋*${prefix}wibu
▋┋*${prefix}ramalhp
▋┋*${prefix}infomobil
▋┋*${prefix}infomotor
▋┋*${prefix}brainly
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙_Owner fitur_
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}bc -promosi*
▋┋*${prefix}ban -banned
▋┋*${prefix}block -blok
▋┋*${prefix}unblok
▋┋*${prefix}clearall
▋┋*${prefix}clone
▋┋*${prefix}getses
▋┋*${prefix}setpp
▋┋*${prefix}leave
═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡
*(•♛•)─•••──ೇุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุ──────﹒ׂׂૢ་༘࿐ೢִֶָ──╮*
*▄▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▄*        
    *┏ೋ┉━┉ೋ✧ೋ┉━┉ೋ┓*
                    *EDITOR BERKELAS*
    *┗ೋ┉━┉ೋ✧ೋ┉━┉ೋ┛*
*▀▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▀*       
   ۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈ٜٜٜٜٜٜٜ͡҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ©`
}
exports.help = help
